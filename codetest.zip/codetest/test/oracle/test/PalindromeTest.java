package oracle.test;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Provides sufficient test coverage for oracle.test.PalindromeUtil class.
 */
public class PalindromeUtilTest {
    @Test
    public void testIsPalindromeForPalindromeString() {
        assertTrue(PalindromeUtil.isPalindrome("Madam, I'm Adam."));
        assertTrue(PalindromeUtil.isPalindrome("A man, a plan, a canal, Panama!"));
    }
    
    @Test
    public void testIsPalindromeForNonPalindromeString() {
        assertFalse(PalindromeUtil.isPalindrome("Hello, World!"));
        assertFalse(PalindromeUtil.isPalindrome("This is not a palindrome."));
    }
    
    @Test
    public void testIsPalindromeForEmptyString() {
        assertTrue(PalindromeUtil.isPalindrome(""));
    }
    
    @Test
    public void testIsPalindromeForSingleCharacter() {
        assertTrue(PalindromeUtil.isPalindrome("a"));
        assertTrue(PalindromeUtil.isPalindrome("1"));
    }
    
    @Test
    public void testIsPalindromeForMixedCase() {
        assertTrue(PalindromeUtil.isPalindrome("MaDAm, I'm AdaM."));
        assertFalse(PalindromeUtil.isPalindrome("NoT a PalInDrOmE."));
    }
}
