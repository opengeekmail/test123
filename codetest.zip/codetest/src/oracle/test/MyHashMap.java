package oracle.test;


/**
 *
 * Requirements:
 * - Usage of API from java.util.concurrent package is prohibited.
 * - Usage of java Map and HashMap funxtions are prohibitted.
 * - Limit the amount of additional consumed memory to O(1).
 * - The implementation is supposed to be acceptable for usage in a highly
 * multi-thread environment.
 *
 *
 * Implement a hashmap in java using an array of linked list.
 * implement the method public void put(K key, V value).
 * and implement public V get(K key)
 */
public class MyHashMap<K, V> {


    public MyMap() {
        this(INITIAL_CAPACITY);
    }

    public MyMap(int capacity) {
        this.buckets = new Entry[capacity];
    }

    public void put(K key, V value) {

    }
    public V get(K key) {

    }

}
